# InspectPro — Day 1 portfolio app

**Build:** 0.1.0 starter · **Status:** prototype package, not yet production-hardened or hosted

InspectPro is an original mobile-first inspections, evidence and corrective-action application intended for facilities, cleaning, hospitality, property, retail and other frontline teams. The starter package includes a responsive browser UI, Express API, SQLite data store, bearer-token authentication, role checks, audit records, template creation, inspection submission, automatic corrective-action creation for failed checklist items, action status updates, dashboard summaries and CSV export.

## Demo

- Email: `admin@inspectpro.demo`
- Password: `ChangeMe123!`
- Demo mode seeds one site and a starter Workplace Safety Walk template.
- **Do not deploy with demo credentials or the demo seed.**

## Local setup

Requires Node.js 20+ and build tools for native SQLite module (Python, make, C++ compiler on Linux).

```bash
cp .env.example .env
# Replace JWT_SECRET with a secure random secret, and set DEMO_MODE=false for non-demo use.
npm install
npm start
```
Open http://localhost:3000. To make a first user in non-demo mode, create an owner record using a secure one-time bootstrap procedure or migration (see `docs/DEPLOYMENT.md`). No production bootstrap endpoint is intentionally included.

## Docker

```bash
cp .env.example .env
# Change JWT_SECRET; set DEMO_MODE=true only for local demo
 docker compose up --build
```
Persist `./data`. Use a reverse proxy with TLS, managed secrets, backups and monitoring.

## Main workflow

1. Owner/manager creates checklist template.
2. Inspector selects template/site, completes Pass/Fail/N/A items and adds comments.
3. Submission is scored; failed questions create high-priority follow-up actions.
4. Supervisor assigns, updates status, resolves and verifies action closure.
5. Managers review dashboard and download CSV.

## API

See `docs/API.md`. API requests except health/login need `Authorization: Bearer <token>`.

## Included files

- `src/server.js` — HTTP API, authentication, validation and business workflows
- `src/db.js` — SQLite schema/indexes
- `public/` — frontend
- `docs/` — architecture, threat model, API, market, deployment, product roadmap
- `legal/` — editable legal/IP templates
- `tests/` — basic validation tests

## Known limitations

This is a functional starter prototype, not a production certification or guarantee. It currently uses SQLite (single-instance friendly), simple email/password login, no password reset/MFA/SSO, no organization tenant isolation, no full offline media capture, no secure photo upload endpoint, no email/push integrations, no background scheduler, no server-side report PDF generation, and no deployment pipeline. The offline queue is a best-effort browser JSON queue for text inspection submissions only; it is not encrypted and is not suitable for sensitive records. GPS/signatures/AI are not implemented. Production launch requires the checklist in `docs/DEPLOYMENT.md` and security review.

## IP
The legal templates are draft templates. Name InspectPro is not trademark-cleared. Review trademarks and legal materials with a qualified lawyer before launch. Third-party dependencies are separately licensed; see `legal/DEPENDENCIES.md`.
